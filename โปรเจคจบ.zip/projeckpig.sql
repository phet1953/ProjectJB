-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 01, 2019 at 05:22 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `projeckpig`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity`
--

CREATE TABLE `activity` (
  `ID_activity` int(11) NOT NULL,
  `activity_a` varchar(110) NOT NULL,
  `Isdelete` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `activity`
--

INSERT INTO `activity` (`ID_activity`, `activity_a`, `Isdelete`) VALUES
(1, 'ผสม', 0),
(3, 'ได้รับยา', 0),
(4, 'ป่วย', 0),
(5, 'ทำวัคซีน', 0),
(6, 'กลับสัด', 0),
(7, 'ตาย', 0),
(8, 'ตรวจท้อง', 0),
(9, 'แท้ง', 0),
(10, 'คลอด', 0),
(11, 'ฝากเลี้ยง', 0),
(12, 'รับเลี้ยง', 0),
(13, 'หย่านม', 0),
(15, 'ลูกหมูตาย', 0),
(18, 'ท้องลม', 0);

-- --------------------------------------------------------

--
-- Table structure for table `activity_record`
--

CREATE TABLE `activity_record` (
  `ID_activity_record` int(11) NOT NULL,
  `breeder_b` varchar(50) NOT NULL,
  `date_d` datetime NOT NULL,
  `activity_a` varchar(50) NOT NULL,
  `breederdad_breed` varchar(50) DEFAULT NULL,
  `medicin_getmedicin` varchar(50) DEFAULT NULL,
  `volume_getmedicin` varchar(50) DEFAULT NULL,
  `sick_sick` varchar(50) DEFAULT NULL,
  `note_sick` varchar(50) DEFAULT NULL,
  `drug_drug` varchar(50) DEFAULT NULL,
  `note_inreturn_animal` varchar(50) DEFAULT NULL,
  `note_dead` varchar(50) DEFAULT NULL,
  `results_check_up` varchar(50) DEFAULT NULL,
  `define_check_up` date DEFAULT NULL,
  `text_abortion` varchar(50) DEFAULT NULL,
  `abortion_abortion` varchar(50) DEFAULT NULL,
  `allpigs_deliver` varchar(50) DEFAULT NULL,
  `piglet_alive_deliver` varchar(50) DEFAULT NULL,
  `dead_pig_birth_deliver` varchar(50) DEFAULT NULL,
  `eooukornou_deliver` varchar(50) DEFAULT NULL,
  `pork_litter_deliver` varchar(50) DEFAULT NULL,
  `average_piglets_deliver` varchar(50) DEFAULT NULL,
  `number_deposit_piglet` varchar(50) DEFAULT NULL,
  `breder_deposit_piglet` varchar(50) DEFAULT NULL,
  `number_piglet` varchar(50) DEFAULT NULL,
  `breder_piglet` varchar(50) DEFAULT NULL,
  `number_wean` varchar(50) DEFAULT NULL,
  `pork_litter_wean` varchar(50) DEFAULT NULL,
  `number_piglet_dies` varchar(50) DEFAULT NULL,
  `cause_piglet_dies` varchar(50) DEFAULT NULL,
  `note_piglet_dies` varchar(50) DEFAULT NULL,
  `text_wind_belly` varchar(50) DEFAULT NULL,
  `today_ac` date NOT NULL,
  `Isdelete` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `activity_record`
--

INSERT INTO `activity_record` (`ID_activity_record`, `breeder_b`, `date_d`, `activity_a`, `breederdad_breed`, `medicin_getmedicin`, `volume_getmedicin`, `sick_sick`, `note_sick`, `drug_drug`, `note_inreturn_animal`, `note_dead`, `results_check_up`, `define_check_up`, `text_abortion`, `abortion_abortion`, `allpigs_deliver`, `piglet_alive_deliver`, `dead_pig_birth_deliver`, `eooukornou_deliver`, `pork_litter_deliver`, `average_piglets_deliver`, `number_deposit_piglet`, `breder_deposit_piglet`, `number_piglet`, `breder_piglet`, `number_wean`, `pork_litter_wean`, `number_piglet_dies`, `cause_piglet_dies`, `note_piglet_dies`, `text_wind_belly`, `today_ac`, `Isdelete`) VALUES
(8, '0005', '2019-04-27 00:00:00', 'ผสม', '0003', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', 0),
(10, '0005', '2019-04-27 00:00:00', 'ทำวัคซีน', '0003', NULL, NULL, NULL, NULL, 'pv', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(11, '0005', '2019-04-30 00:00:00', 'ผสม', '0003', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(12, '0005', '2019-04-30 00:00:00', 'ป่วย', '0003', NULL, NULL, 'มีไข้', 'ปานกลาง', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(13, '0005', '2019-05-01 00:00:00', 'ได้รับยา', '0003', 'พารา', '3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(14, '0004', '2019-05-01 00:00:00', 'ตรวจท้อง', '0003', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'แท้ง', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(15, '0005', '2019-05-02 00:00:00', 'ได้รับยา', '0003', 'para', '3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(16, '0005', '2019-05-03 00:00:00', 'ได้รับยา', '0003', 'para', '3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(17, '0005', '2019-05-04 00:00:00', 'ได้รับยา', '0003', 'para', '3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(18, '0006', '2019-04-30 00:00:00', 'ตรวจท้อง', '0003', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ไม่ท้อง', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(19, '0005', '0000-00-00 00:00:00', 'ผสม', '0003', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(20, '0005', '2019-05-02 17:45:06', 'ผสม', '0008', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(21, '0005', '2019-05-22 17:49:07', 'แท้ง', '0003', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'gfdgert', '34', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(22, '0009', '2019-05-01 19:39:15', 'ท้องลม', '0003', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', 0),
(23, '0009', '2019-05-02 19:39:21', 'ท้องลม', '0003', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', 0),
(24, '0009', '2019-05-03 19:39:25', 'ท้องลม', '0003', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', 0),
(25, '0009', '2019-05-04 19:39:31', 'ท้องลม', '0003', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', 0),
(26, '0009', '2019-05-05 19:39:35', 'ท้องลม', '0003', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', 0),
(27, '0009', '2019-05-06 19:40:57', 'ท้องลม', '0003', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '0000-00-00', 0),
(28, '0009', '2019-05-07 19:41:14', 'ท้องลม', '0003', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ww', '0000-00-00', 0),
(29, '0005', '2019-05-15 17:13:05', 'ลูกหมูตาย', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'ป่วย', '', NULL, '0000-00-00', 0),
(30, '0002', '2019-05-17 17:14:11', 'รับเลี้ยง', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4', '0005', NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(31, '0009', '2019-05-16 19:01:30', 'ตรวจท้อง', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ท้อง', '2019-07-16', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(32, '0009', '2019-05-20 20:22:43', 'ได้รับยา', NULL, 'para', '2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(33, '0009', '2019-06-10 21:53:50', 'ได้รับยา', NULL, 'para', '3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(34, '0009', '2019-06-09 22:01:52', 'ได้รับยา', NULL, 'para', '3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(35, '0005', '2019-06-10 22:03:06', 'ได้รับยา', NULL, 'para', '4', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(36, '0008', '2019-06-11 15:17:20', 'ป่วย', NULL, NULL, NULL, 'ขาเจ็บ', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(37, '0008', '2019-06-10 15:17:40', 'ป่วย', NULL, NULL, NULL, 'ไม่กินอาหาร', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(38, '0008', '2019-06-09 15:21:14', 'ป่วย', NULL, NULL, NULL, 'มีแผล', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(39, '0005', '2019-06-11 16:12:50', 'ได้รับยา', NULL, 'para', '3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(53, '0008', '2019-06-12 19:51:06', 'ป่วย', NULL, NULL, NULL, 'มีไข้', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(54, '0008', '2019-06-08 19:54:28', 'ป่วย', NULL, NULL, NULL, 'มีไข้', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(55, '0008', '2019-06-06 20:00:27', 'ท้องลม', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', 0),
(56, '0008', '2019-06-05 20:00:45', 'ท้องลม', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', 0),
(57, '0008', '2019-06-13 20:02:08', 'ป่วย', NULL, NULL, NULL, 'มีไข้', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(58, '0008', '2019-06-22 15:27:09', 'ป่วย', NULL, NULL, NULL, 'มีไข้', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(59, '0003', '2019-06-23 16:37:04', 'คลอด', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '15', '13', '1', '1', '150', '10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(60, '0014', '2019-06-11 22:57:28', 'ป่วย', NULL, NULL, NULL, 'ขาเจ็บ', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(61, '0014', '2019-06-12 22:57:39', 'ป่วย', NULL, NULL, NULL, 'ขาเจ็บ', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(62, '0014', '2019-06-13 22:57:50', 'ป่วย', NULL, NULL, NULL, 'ขาเจ็บ', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(63, '0014', '2019-06-14 22:58:04', 'ป่วย', NULL, NULL, NULL, 'มีไข้', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(64, '0014', '2019-06-15 22:58:21', 'ป่วย', NULL, NULL, NULL, 'ขาเจ็บ', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(65, '0007', '2019-06-03 12:23:12', 'ตรวจท้อง', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ท้อง', '2019-06-27', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-07-10', 2),
(66, '0007', '2019-06-05 12:23:29', 'ได้รับยา', NULL, 'para', '3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-07-10', 2),
(67, '0007', '2019-06-05 12:23:46', 'ป่วย', NULL, NULL, NULL, 'มีแผล', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-07-10', 2),
(68, '0007', '2019-06-06 12:24:05', 'ป่วย', NULL, NULL, NULL, 'มีแผล', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-07-10', 2),
(69, '0007', '2019-06-07 12:24:23', 'แท้ง', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '7', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-07-10', 2),
(70, '0007', '2019-06-08 12:24:58', 'ป่วย', NULL, NULL, NULL, 'มีไข้', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-07-10', 2),
(71, '0007', '2019-06-09 12:25:13', 'ป่วย', NULL, NULL, NULL, 'มีไข้', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-07-10', 2),
(72, '0007', '2019-06-10 12:25:33', 'ป่วย', NULL, NULL, NULL, 'ท้องเสีย', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-07-10', 2),
(73, '0002', '2019-06-26 13:54:12', 'ป่วย', NULL, NULL, NULL, 'มีไข้', '35 องศา', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(74, '0009', '2019-06-02 19:53:13', 'ป่วย', NULL, NULL, NULL, 'มีไข้', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(75, '0009', '2019-06-03 19:53:29', 'ป่วย', NULL, NULL, NULL, 'มีไข้', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(76, '0009', '2019-06-04 19:53:48', 'ป่วย', NULL, NULL, NULL, 'มีไข้', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(77, '0009', '2019-06-05 19:54:04', 'ป่วย', NULL, NULL, NULL, 'มีไข้', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(78, '0009', '2019-06-06 19:54:19', 'ป่วย', NULL, NULL, NULL, 'มีไข้', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(79, '0009', '2019-05-05 19:55:19', 'แท้ง', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(80, '0009', '2019-05-06 19:55:39', 'แท้ง', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(81, '0009', '2019-05-07 19:55:53', 'แท้ง', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(82, '0009', '2019-05-08 19:56:07', 'แท้ง', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(83, '0009', '2019-05-09 19:56:35', 'แท้ง', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(84, '0008', '2019-04-08 20:30:12', 'ท้องลม', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', 0),
(85, '0008', '2019-04-09 20:30:26', 'ท้องลม', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', 0),
(86, '0008', '2019-04-10 20:30:52', 'ท้องลม', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', 0),
(87, '0019', '2019-07-10 18:36:01', 'ป่วย', NULL, NULL, NULL, 'ขาเป็นแผล', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-07-10', 4),
(88, '0018', '2019-07-10 18:36:17', 'ได้รับยา', NULL, 'พารา', '3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-07-10', 4),
(89, '0008', '2019-07-17 13:13:35', 'ป่วย', NULL, NULL, NULL, 'มีไข้', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 0),
(92, '0125', '2019-07-22 22:47:54', 'ตาย', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '-', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', 5);

-- --------------------------------------------------------

--
-- Table structure for table `breed`
--

CREATE TABLE `breed` (
  `ID_breed` int(11) NOT NULL,
  `breed_b` varchar(100) NOT NULL,
  `Isdelete` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `breed`
--

INSERT INTO `breed` (`ID_breed`, `breed_b`, `Isdelete`) VALUES
(1, 'หมูพันธุ์ไหหลำ', 0),
(2, 'หมูพันธุ์ควาย', 0),
(3, 'หมูพันธุ์ราด', 0),
(4, 'หมูพันธุ์พวง', 0),
(5, 'หมูพันธุ์แลนด์เรซ', 0),
(6, 'หมูพันธุ์ลาร์จไวต์', 0),
(7, 'หมูพันธุ์ดูร็อก', 0),
(8, 'หมูพันธุ์ลูกผสม', 0),
(9, 'หมูพันธ์ุป่า', 0);

-- --------------------------------------------------------

--
-- Table structure for table `breeder`
--

CREATE TABLE `breeder` (
  `ID_breeder` int(11) NOT NULL,
  `No_b` varchar(4) NOT NULL,
  `dad_b` varchar(4) NOT NULL,
  `mom_b` varchar(4) NOT NULL,
  `birthday_b` date NOT NULL,
  `birthfrom_b` date NOT NULL,
  `breed_b` varchar(100) NOT NULL,
  `form_b` varchar(100) NOT NULL,
  `Isdelete` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `breeder`
--

INSERT INTO `breeder` (`ID_breeder`, `No_b`, `dad_b`, `mom_b`, `birthday_b`, `birthfrom_b`, `breed_b`, `form_b`, `Isdelete`) VALUES
(1, '0009', '0001', '0007', '0000-00-00', '0000-00-00', 'หมูพันธุ์ไหหลำ', '', 0),
(2, '0000', '0034', '0004', '2019-02-25', '2019-03-28', 'หมูพันธุ์ควาย', '', 0),
(3, '0002', '0003', '0003', '2019-04-16', '2019-04-30', 'หมูพันธุ์ไหหลำ', '', 0),
(4, '0005', '0001', '0007', '2019-04-15', '2019-04-15', 'หมูพันธุ์ควาย', '', 0),
(5, '0008', '0003', '0003', '2019-04-01', '2019-04-08', 'หมูพันธุ์ราด', '', 0),
(6, '0006', '0003', '0003', '2019-04-30', '2019-04-30', 'หมูพันธุ์ราด', '', 0),
(7, '0007', '0003', '0004', '2019-04-01', '2019-04-30', 'หมูพันธุ์ราด', '', 0),
(8, '0014', '0001', '0001', '2019-05-06', '2019-05-30', 'หมูพันธุ์ราด', '', 0),
(9, '0019', '0031', '0011', '2019-01-22', '2019-05-22', 'หมูพันธุ์ลูกผสม', '', 0),
(10, '0018', '0004', '0018', '2019-05-16', '2019-07-25', 'หมูพันธุ์ราด', '', 0),
(11, '0124', '0009', '0009', '2019-07-15', '2019-07-17', 'หมูพันธุ์ลูกผสม', '', 0),
(12, '0020', '0004', '0004', '2019-07-23', '2019-07-10', 'หมูพันธุ์ไหหลำ', '', 0),
(13, '0125', '0006', '0006', '2019-07-15', '2019-07-04', 'หมูพันธุ์ไหหลำ', '', 5);

-- --------------------------------------------------------

--
-- Table structure for table `breederdad`
--

CREATE TABLE `breederdad` (
  `ID_breederdad` int(11) NOT NULL,
  `No_b` varchar(4) NOT NULL,
  `dad_b` varchar(4) NOT NULL,
  `mom_b` varchar(4) NOT NULL,
  `birthday_b` date NOT NULL,
  `birthfrom_b` date NOT NULL,
  `datdet_d` date NOT NULL,
  `age_b` int(11) NOT NULL,
  `breed_b` varchar(100) NOT NULL,
  `form_b` varchar(100) NOT NULL,
  `Isdelete` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `breederdad`
--

INSERT INTO `breederdad` (`ID_breederdad`, `No_b`, `dad_b`, `mom_b`, `birthday_b`, `birthfrom_b`, `datdet_d`, `age_b`, `breed_b`, `form_b`, `Isdelete`) VALUES
(8, '0004', '0008', '0008', '2019-04-08', '2019-04-08', '2019-05-08', 1, 'หมูพันธุ์ควาย', '', 0),
(9, '0012', '0001', '0001', '2019-04-30', '2019-04-22', '2019-04-29', 1, 'หมูพันธุ์ราด', '', 0),
(10, '0010', '0002', '0002', '2019-04-02', '2019-04-02', '2019-04-08', 2, 'หมูพันธุ์ไหหลำ', '', 0),
(11, '0001', '0001', '0003', '2019-04-16', '2019-04-01', '2019-04-16', 3, 'หมูพันธุ์ไหหลำ', '', 0),
(15, '0123', '1234', '0031', '2019-05-22', '2019-05-22', '2019-05-22', 5, 'หมูพันธุ์ลูกผสม', '', 0),
(16, '0126', '0006', '0006', '2019-07-25', '2019-07-16', '2019-07-10', 3, 'หมูพันธุ์ไหหลำ', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `checkbelly`
--

CREATE TABLE `checkbelly` (
  `ID_checkbelly` int(11) NOT NULL,
  `checkbelly_c` varchar(100) NOT NULL,
  `Isdelete` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `checkbelly`
--

INSERT INTO `checkbelly` (`ID_checkbelly`, `checkbelly_c`, `Isdelete`) VALUES
(1, 'ท้อง', 0),
(3, 'ไม่ท้อง', 0),
(5, 'แท้ง', 0),
(6, 'ท้องลม', 0);

-- --------------------------------------------------------

--
-- Table structure for table `compadrug`
--

CREATE TABLE `compadrug` (
  `ID_compadrug` int(11) NOT NULL,
  `compadrug_c` varchar(100) NOT NULL,
  `Isdelete` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `compadrug`
--

INSERT INTO `compadrug` (`ID_compadrug`, `compadrug_c`, `Isdelete`) VALUES
(1, 'บริษัทฟาร์มมาซิ', 0),
(2, 'บริษัทเภสัชกร', 0),
(3, 'แพร่ฟาร์มมาซิ', 0),
(4, 'ลำปางฟาร์มมาซิ', 0),
(5, 'นครสวรรค์ฟาร์มมาซิ', 0),
(6, 'แพร่เภสัชกร', 1);

-- --------------------------------------------------------

--
-- Table structure for table `drug`
--

CREATE TABLE `drug` (
  `ID_drug` int(11) NOT NULL,
  `com_c` varchar(100) NOT NULL,
  `drug_d` varchar(100) NOT NULL,
  `cc_c` varchar(100) NOT NULL,
  `product_p` varchar(100) NOT NULL,
  `use_u` varchar(100) NOT NULL,
  `Isdelete` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `drug`
--

INSERT INTO `drug` (`ID_drug`, `com_c`, `drug_d`, `cc_c`, `product_p`, `use_u`, `Isdelete`) VALUES
(1, 'บริษัทฟาร์มมาซิ', 'pv', '10', 'Suvaxyn parvo', 'ยาฉีด', 0),
(2, 'แพร่ฟาร์มมาซิ', 'FMd', '11', 'Aftopor2', '3', 0),
(3, 'บริษัทฟาร์มมาซิ', 'SF', '8', 'Sfinea', '', 0),
(4, 'บริษัทฟาร์มมาซิ', 'BBA', '2', 'dkdk', '', 0),
(9, 'บริษัทเภสัชกร', 'asd', '5', 'asd', 'asd', 0);

-- --------------------------------------------------------

--
-- Table structure for table `duty`
--

CREATE TABLE `duty` (
  `ID_duty` int(11) NOT NULL,
  `duty_d` varchar(100) NOT NULL,
  `Isdelete` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `duty`
--

INSERT INTO `duty` (`ID_duty`, `duty_d`, `Isdelete`) VALUES
(1, 'แอดมิน', 0),
(3, 'สัตวแพทย์ประจำฟาร์ม', 0),
(4, 'เจ้าหน้าที่ประจำฟาร์ม', 0);

-- --------------------------------------------------------

--
-- Table structure for table `farm`
--

CREATE TABLE `farm` (
  `ID_farm` int(11) NOT NULL,
  `far_f` varchar(50) NOT NULL,
  `farmown_f` varchar(100) NOT NULL,
  `mowntel_m` int(100) NOT NULL,
  `farfarm_f` varchar(100) NOT NULL,
  `telfarm_t` int(100) NOT NULL,
  `farmaddress_f` varchar(100) NOT NULL,
  `farmtel_f` int(100) NOT NULL,
  `warrantdate_w` date NOT NULL,
  `Isdelete` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `farm`
--

INSERT INTO `farm` (`ID_farm`, `far_f`, `farmown_f`, `mowntel_m`, `farfarm_f`, `telfarm_t`, `farmaddress_f`, `farmtel_f`, `warrantdate_w`, `Isdelete`) VALUES
(9, 'ฟาร์มนครสวรรค์', 'พงศธร ศรีจันทร์', 992378884, 'ศุภกฤต ม่วงเมือง', 833333335, '282 หมู่ 1 ต.แม่วงก์ อ.แม่วงก์ จ.นครสวรรค์ 60150', 56785678, '2019-07-01', 1),
(10, 'ฟาร์มเชียงใหม่', 'พงศธร ศรีจันทร์', 912875541, 'พงศธร ศรีจันทร์', 992378884, '282 หมู่ 1 ต.แม่วงก์ อ.แม่วงก์ จ.นครสวรรค์ 60150', 59128755, '2017-06-10', 0);

-- --------------------------------------------------------

--
-- Table structure for table `medicin`
--

CREATE TABLE `medicin` (
  `ID_medicin` int(11) NOT NULL,
  `unitdrug_u` varchar(100) NOT NULL,
  `medicin_m` varchar(100) NOT NULL,
  `munitdrug_m` varchar(100) NOT NULL,
  `act_a` varchar(100) NOT NULL,
  `methoddrug_m` varchar(100) NOT NULL,
  `percent_p` varchar(100) NOT NULL,
  `registration_r` varchar(100) NOT NULL,
  `stop_s` varchar(100) NOT NULL,
  `comname_c` varchar(100) NOT NULL,
  `use_u` varchar(100) NOT NULL,
  `objdrug_o` varchar(20) NOT NULL,
  `Isdelete` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `medicin`
--

INSERT INTO `medicin` (`ID_medicin`, `unitdrug_u`, `medicin_m`, `munitdrug_m`, `act_a`, `methoddrug_m`, `percent_p`, `registration_r`, `stop_s`, `comname_c`, `use_u`, `objdrug_o`, `Isdelete`) VALUES
(1, 'มิลลิกรัม/ซีซี', 'para', 'มิลลิกรัม/ตัว', 'as', 'ฉีด', '3', 'as', '2', 'บริษัทฟาร์มมาซิ', '', 'รักษา', 0),
(2, 'มิลลิกรัม/ซีซี', 'พารา', 'มิลลิกรัม/ตัว', 'พาราเซนตามอล', 'ฉีด', '2', '1234', '2', 'บริษัทเภสัชกร', 'ห้ามใช้ยาเกิน7วัน', '', 0),
(4, 'มิลลิกรัม/ซีซี', 'KONOVID', 'มิลลิกรัม/ตัว', 'KONOVID', 'ฉีด', '5', '2345', '5', 'บริษัทเภสัชกร', '', 'รักษา', 0),
(5, 'มิลลิกรัม/ซีซี', 'D-nee', 'มิลลิกรัม/ตัว', 'D-nee', 'ผสมอาหาร', '3', 'D-nee124', '5', 'แพร่ฟาร์มมาซิ', 'as', 'ป้องกัน', 0),
(6, 'กรัม/ซีซี', 'Baygon', 'ซีซี/กก.', 'Baygon', 'ผสมน้ำ', '5', 'Baygon123', '3', 'นครสวรรค์ฟาร์มมาซิ', 'as', 'ป้องกัน', 0);

-- --------------------------------------------------------

--
-- Table structure for table `methoddrug`
--

CREATE TABLE `methoddrug` (
  `ID_methoddrug` int(11) NOT NULL,
  `methoddrug_m` varchar(100) NOT NULL,
  `Isdelete` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `methoddrug`
--

INSERT INTO `methoddrug` (`ID_methoddrug`, `methoddrug_m`, `Isdelete`) VALUES
(1, 'ฉีด', 0),
(2, 'ผสมอาหาร', 0),
(3, 'ผสมน้ำ', 0),
(4, 'คลุก', 1);

-- --------------------------------------------------------

--
-- Table structure for table `munitdrug`
--

CREATE TABLE `munitdrug` (
  `ID_munitdrug` int(11) NOT NULL,
  `munitdrug_m` varchar(100) NOT NULL,
  `Isdelete` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `munitdrug`
--

INSERT INTO `munitdrug` (`ID_munitdrug`, `munitdrug_m`, `Isdelete`) VALUES
(1, 'มิลลิกรัม/กก.', 0),
(2, 'มิลลิกรัม/ตัว', 0),
(3, 'ซีซี/กก.', 0),
(4, 'ซีซี/ตัว.', 0),
(5, 'กรัม/กก.', 1);

-- --------------------------------------------------------

--
-- Table structure for table `objdrug`
--

CREATE TABLE `objdrug` (
  `ID_objdrug` int(11) NOT NULL,
  `objdrug_o` varchar(100) NOT NULL,
  `Isdelete` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `objdrug`
--

INSERT INTO `objdrug` (`ID_objdrug`, `objdrug_o`, `Isdelete`) VALUES
(1, 'รักษา', 0),
(2, 'ป้องกัน', 0),
(3, 'บรรเทา', 0),
(4, 'แก้ปวด', 0),
(5, 'แก้ท้องเสีย', 1);

-- --------------------------------------------------------

--
-- Table structure for table `proviso`
--

CREATE TABLE `proviso` (
  `ID_proviso` int(11) NOT NULL,
  `name_proviso` varchar(20) NOT NULL,
  `number_proviso` varchar(20) NOT NULL,
  `txt_proviso` varchar(10) NOT NULL,
  `Isdelete` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `proviso`
--

INSERT INTO `proviso` (`ID_proviso`, `name_proviso`, `number_proviso`, `txt_proviso`, `Isdelete`) VALUES
(1, 'ท้องลม', '2', '/ครั้ง', 0),
(2, 'แท้ง', '2', '/ครั้ง', 1),
(3, 'ลูกหมูตาย', '5', '/ตัว', 1),
(4, 'ฝากเลี้ยง', '5', '/ครั้ง', 1),
(5, 'ป่วย', '2', '/ครั้ง', 0);

-- --------------------------------------------------------

--
-- Table structure for table `resdie`
--

CREATE TABLE `resdie` (
  `ID_resdie` int(11) NOT NULL,
  `resdie_r` varchar(100) NOT NULL,
  `Isdelete` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `resdie`
--

INSERT INTO `resdie` (`ID_resdie`, `resdie_r`, `Isdelete`) VALUES
(1, 'ท้องเสีย', 0),
(2, 'ซัก', 0),
(3, 'อ่อนแอ', 0),
(4, 'ไข้หวัด', 0),
(6, 'ป่วย', 0);

-- --------------------------------------------------------

--
-- Table structure for table `sick`
--

CREATE TABLE `sick` (
  `ID_sick` int(11) NOT NULL,
  `sick_s` varchar(100) NOT NULL,
  `Isdelete` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sick`
--

INSERT INTO `sick` (`ID_sick`, `sick_s`, `Isdelete`) VALUES
(1, 'มีไข้', 0),
(3, 'ขาเจ็บ', 0),
(4, 'ไม่กินอาหาร', 0),
(5, 'ท้องเสีย', 0),
(6, 'มีแผล', 0),
(7, 'ท้องผุ', 1),
(8, 'ขาเป็นแผล', 0);

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `ID_login` int(11) NOT NULL,
  `usernames` varchar(100) NOT NULL,
  `passwords` varchar(100) NOT NULL,
  `name_n` varchar(100) NOT NULL,
  `lastname_l` varchar(100) NOT NULL,
  `idcard` varchar(14) NOT NULL,
  `house_no` varchar(100) NOT NULL,
  `postal_code` varchar(10) NOT NULL,
  `email_e` varchar(100) NOT NULL,
  `birthday_b` date NOT NULL,
  `professional_number` varchar(100) NOT NULL,
  `duty_d` varchar(100) NOT NULL,
  `tel_t` int(11) NOT NULL,
  `Isdelete` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`ID_login`, `usernames`, `passwords`, `name_n`, `lastname_l`, `idcard`, `house_no`, `postal_code`, `email_e`, `birthday_b`, `professional_number`, `duty_d`, `tel_t`, `Isdelete`) VALUES
(1, 'admin', 'admin1234', 'พงศธร ศรีจันทร์', 'เพชร', '1749900548975', '282 หมู่1 ต.แม่วงก์ อ.แม่วงก์ จ.นครสวรรค์', '60150', 'phet_1953@hotmail.com', '1997-04-28', '-', 'แอดมิน', 912875541, 0),
(3, 'vete', 'vete1234', 'นพ.นพดร  ดวงดี', 'นพ', '1856396580436', '1/3 หมู่1 ต.นางรอง อ. เมือง จ.บุรีรัมย์', '30000', 'np123@gmail.com', '1978-01-03', '21474836472344', 'สัตวแพทย์ประจำฟาร์ม', 912875545, 0),
(4, 'staff', 'staff1234', 'เอกพล มารี', 'เอก', '2744038563084', '700/3 หมู่1 ต.กระทุ่มแบน อ. เมือง จ.สมุทสาคร ', '74000', 'axfix1@gmail.com', '1992-09-05', '-', 'เจ้าหน้าที่ประจำฟาร์ม', 912875541, 0),
(5, 'as', 'as', 'as', 'as', '2122222222222', 'as', '345', 'made44@gmail.com', '2019-07-02', 'as', 'แอดมิน', 965, 0);

-- --------------------------------------------------------

--
-- Table structure for table `unitdrug`
--

CREATE TABLE `unitdrug` (
  `ID_unitdrug` int(11) NOT NULL,
  `unitdrug_u` varchar(110) NOT NULL,
  `Isdelete` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `unitdrug`
--

INSERT INTO `unitdrug` (`ID_unitdrug`, `unitdrug_u`, `Isdelete`) VALUES
(1, 'มิลลิกรัม/ซีซี', 0),
(2, 'microgram/cc', 0),
(3, 'micro', 0),
(4, 'กรัม/ซีซี', 0),
(5, '', 1),
(6, '', 1),
(7, '', 1),
(8, '', 1),
(9, '', 1),
(10, '', 1),
(11, '', 1),
(12, 'กรัม/ซีซี', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity`
--
ALTER TABLE `activity`
  ADD PRIMARY KEY (`ID_activity`);

--
-- Indexes for table `activity_record`
--
ALTER TABLE `activity_record`
  ADD PRIMARY KEY (`ID_activity_record`);

--
-- Indexes for table `breed`
--
ALTER TABLE `breed`
  ADD PRIMARY KEY (`ID_breed`);

--
-- Indexes for table `breeder`
--
ALTER TABLE `breeder`
  ADD PRIMARY KEY (`ID_breeder`);

--
-- Indexes for table `breederdad`
--
ALTER TABLE `breederdad`
  ADD PRIMARY KEY (`ID_breederdad`);

--
-- Indexes for table `checkbelly`
--
ALTER TABLE `checkbelly`
  ADD PRIMARY KEY (`ID_checkbelly`);

--
-- Indexes for table `compadrug`
--
ALTER TABLE `compadrug`
  ADD PRIMARY KEY (`ID_compadrug`);

--
-- Indexes for table `drug`
--
ALTER TABLE `drug`
  ADD PRIMARY KEY (`ID_drug`);

--
-- Indexes for table `duty`
--
ALTER TABLE `duty`
  ADD PRIMARY KEY (`ID_duty`);

--
-- Indexes for table `farm`
--
ALTER TABLE `farm`
  ADD PRIMARY KEY (`ID_farm`);

--
-- Indexes for table `medicin`
--
ALTER TABLE `medicin`
  ADD PRIMARY KEY (`ID_medicin`);

--
-- Indexes for table `methoddrug`
--
ALTER TABLE `methoddrug`
  ADD PRIMARY KEY (`ID_methoddrug`);

--
-- Indexes for table `munitdrug`
--
ALTER TABLE `munitdrug`
  ADD PRIMARY KEY (`ID_munitdrug`);

--
-- Indexes for table `objdrug`
--
ALTER TABLE `objdrug`
  ADD PRIMARY KEY (`ID_objdrug`);

--
-- Indexes for table `proviso`
--
ALTER TABLE `proviso`
  ADD PRIMARY KEY (`ID_proviso`);

--
-- Indexes for table `resdie`
--
ALTER TABLE `resdie`
  ADD PRIMARY KEY (`ID_resdie`);

--
-- Indexes for table `sick`
--
ALTER TABLE `sick`
  ADD PRIMARY KEY (`ID_sick`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`ID_login`);

--
-- Indexes for table `unitdrug`
--
ALTER TABLE `unitdrug`
  ADD PRIMARY KEY (`ID_unitdrug`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity`
--
ALTER TABLE `activity`
  MODIFY `ID_activity` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `activity_record`
--
ALTER TABLE `activity_record`
  MODIFY `ID_activity_record` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;

--
-- AUTO_INCREMENT for table `breed`
--
ALTER TABLE `breed`
  MODIFY `ID_breed` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `breeder`
--
ALTER TABLE `breeder`
  MODIFY `ID_breeder` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `breederdad`
--
ALTER TABLE `breederdad`
  MODIFY `ID_breederdad` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `checkbelly`
--
ALTER TABLE `checkbelly`
  MODIFY `ID_checkbelly` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `compadrug`
--
ALTER TABLE `compadrug`
  MODIFY `ID_compadrug` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `drug`
--
ALTER TABLE `drug`
  MODIFY `ID_drug` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `duty`
--
ALTER TABLE `duty`
  MODIFY `ID_duty` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `farm`
--
ALTER TABLE `farm`
  MODIFY `ID_farm` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `medicin`
--
ALTER TABLE `medicin`
  MODIFY `ID_medicin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `methoddrug`
--
ALTER TABLE `methoddrug`
  MODIFY `ID_methoddrug` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `munitdrug`
--
ALTER TABLE `munitdrug`
  MODIFY `ID_munitdrug` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `objdrug`
--
ALTER TABLE `objdrug`
  MODIFY `ID_objdrug` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `proviso`
--
ALTER TABLE `proviso`
  MODIFY `ID_proviso` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `resdie`
--
ALTER TABLE `resdie`
  MODIFY `ID_resdie` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `sick`
--
ALTER TABLE `sick`
  MODIFY `ID_sick` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `ID_login` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `unitdrug`
--
ALTER TABLE `unitdrug`
  MODIFY `ID_unitdrug` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
